export const handler = async (event) => {
  return {
    id: new Date().getTime(),
    type: "This is from Lambda(zipped)",
    message: "This is from Lambda(zipped)",
    playerId: "This is from Lambda(zipped)",
    createdAt: new Date(),
    updatedAt: new Date(),
  };
};
